package com.devdaljeet.cardealershipsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarDealershipSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarDealershipSystemApplication.class, args);
	}

}
