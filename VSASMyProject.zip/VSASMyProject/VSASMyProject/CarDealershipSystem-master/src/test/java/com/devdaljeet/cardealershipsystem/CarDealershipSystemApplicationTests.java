package com.devdaljeet.cardealershipsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarDealershipSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
